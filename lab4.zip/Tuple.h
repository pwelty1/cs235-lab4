#ifndef TUPLE
#define TUPLE
//CAN BE EMPY!!!!!
#include <iostream>
#include <string>
#include <cctype>
#include <fstream>
#include <vector>
#include <set>
#include <iterator>
#include <exception>

using namespace std;

class Tuple : public vector<string> {

  private:

  public:

};

#endif
