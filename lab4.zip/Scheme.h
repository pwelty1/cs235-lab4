#ifndef SCHEME
#define SCHEME
//CAN BE EMPY!!!!!
#include <iostream>
#include <string>
#include <cctype>
#include <fstream>
#include <vector>
#include <set>
#include <iterator>
#include <exception>

using namespace std;

class Scheme : public vector<string> {

  private:

  public:

};

#endif
